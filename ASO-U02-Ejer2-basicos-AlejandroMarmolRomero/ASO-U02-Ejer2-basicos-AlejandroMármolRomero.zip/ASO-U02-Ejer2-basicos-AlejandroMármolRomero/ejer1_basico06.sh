# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
#
# Crear   un   script   con   nombre  ejer1_basico06.sh    que   modifique   el   script
# ejer1_basico01.sh de modo que uses una variable. La variable almacenará el mensaje
# "¡La programación de scripts es divertida!"

VAR="$(bash /root/ASO-U02-Ejer2-basicos-AlejandroMármolRomero/ejer1_basico01.sh)"
echo "$VAR"
