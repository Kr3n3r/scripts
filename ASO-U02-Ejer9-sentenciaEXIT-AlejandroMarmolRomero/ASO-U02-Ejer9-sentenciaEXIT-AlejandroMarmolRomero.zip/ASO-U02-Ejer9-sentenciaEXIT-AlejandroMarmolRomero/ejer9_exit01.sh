# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022

# descripción: script que sale con estado de salida 0
# uso: bash ejer9_exit01.sh

echo "Este script saldrá con un estado de salida 0"
exit 0
