# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022

# descripción: script que muestra por pantalla la siguientes palabras en una línea cada una
# uso: bash ejer7_for01.sh

for ANIMAL in "hombre" "oso" "caballo" "perro" "gato" "oveja"
do
	echo $ANIMAL;
done
