# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
#
# Crear un script con nombre ejer1_basico08.sh que pueda mostrar información (ayuda
# del comando man) de un comando pasado por parámetro.

man $1
