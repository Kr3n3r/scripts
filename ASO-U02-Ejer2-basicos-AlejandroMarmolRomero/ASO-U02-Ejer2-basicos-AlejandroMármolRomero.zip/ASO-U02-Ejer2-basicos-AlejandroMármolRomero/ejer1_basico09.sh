# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
#
# Realizar   un   script   con   nombre  ejer1_basico09.sh    que   indique   los   parámetros
# utilizados así como el número de los mismos.
# El script  (sunombre) ha recibido (nº de parámetros ) parámetros. y son:
# ................

echo "El script $0 ha recibido $# parámetros. y son:"
echo "$@"
