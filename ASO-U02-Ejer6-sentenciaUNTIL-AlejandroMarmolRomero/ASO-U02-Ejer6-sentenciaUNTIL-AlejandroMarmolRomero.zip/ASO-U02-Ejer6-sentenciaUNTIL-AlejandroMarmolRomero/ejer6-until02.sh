# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022

# descripcion: script que muestra un mensaje cada 90 min
# entrada: bash ejer6_until02.sh

until false
do
	sleep 90m
	echo "Hacer la tarea"
done
