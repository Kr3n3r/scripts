# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022

# descripcion: script que muestra un mensaje cada 90 min
# entrada: bash ejer5_while02.sh

clear

n=0
while [ n=0 ]
do
	sleep 90m
	echo "Hacer tareas"
done



