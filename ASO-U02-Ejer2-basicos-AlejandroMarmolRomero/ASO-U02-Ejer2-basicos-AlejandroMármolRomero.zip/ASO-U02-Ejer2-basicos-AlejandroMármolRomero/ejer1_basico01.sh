# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
# Crea un script con nombre ejer1_basico01.sh que imprima en pantalla 
# "¡La programación de scripts es divertida!"

echo "¡La programación de scripts es divertida!"
