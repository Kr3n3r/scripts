# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
# Crear un script con nombre ejer1_basico03.sh  que crea un fichero con el contenido
# de todos los ficheros que existen en el directorio actual. Suponer que todos los ficheros
# del directorio actual son de texto y que no sabemos ni como se llaman los ficheros ni
# cuantos hay actualmente en el directorio.

rm directorio
mkdir directorio
cp *.txt ./directorio
