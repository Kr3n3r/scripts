# !/bin/bash
# author: Alejandro Mármol Romero
# curso: 2021-2022
#
# Crear un script con nombre ejer1_basico11.sh que te pida por teclado tu nombre y tus
# apellidos y te salude.

echo "Introduce tu nombre"; read NOMBRE

echo "Hola $NOMBRE!"
